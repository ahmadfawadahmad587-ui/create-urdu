// ===== URDU TRANSLATOR - Popup Script =====

const inputText = document.getElementById('inputText');
const translateBtn = document.getElementById('translateBtn');
const clearBtn = document.getElementById('clearBtn');
const pasteBtn = document.getElementById('pasteBtn');
const copyBtn = document.getElementById('copyBtn');
const speakBtn = document.getElementById('speakBtn');
const resultSection = document.getElementById('resultSection');
const resultBox = document.getElementById('resultBox');
const detectedLang = document.getElementById('detectedLang');
const loading = document.getElementById('loading');
const errorBox = document.getElementById('errorBox');
const errorMsg = document.getElementById('errorMsg');
const charCount = document.getElementById('charCount');
const countDisplay = document.getElementById('countDisplay');
const toast = document.getElementById('toast');
const tipBox = document.getElementById('tipBox');
const chips = document.querySelectorAll('.chip');

document.addEventListener('DOMContentLoaded', () => {
  loadStats();
  inputText.focus();
  chrome.storage.local.get(['pendingTranslation'], (data) => {
    if (data.pendingTranslation) {
      inputText.value = data.pendingTranslation;
      updateCharCount();
      chrome.storage.local.remove('pendingTranslation');
      doTranslate();
    }
  });
});

function loadStats() {
  chrome.runtime.sendMessage({ action: 'getStats' }, (response) => {
    if (response && response.translationCount !== undefined) {
      countDisplay.textContent = response.translationCount;
    }
  });
}

inputText.addEventListener('input', updateCharCount);
function updateCharCount() {
  charCount.textContent = inputText.value.length;
}

translateBtn.addEventListener('click', doTranslate);

inputText.addEventListener('keydown', (e) => {
  if (e.ctrlKey && e.key === 'Enter') {
    doTranslate();
  }
});

function doTranslate() {
  const text = inputText.value.trim();
  if (!text) {
    showError('براہ کرم متن درج کریں۔ (Please enter text to translate)');
    return;
  }
  setLoading(true);
  hideError();
  hideResult();
  tipBox.style.display = 'none';
  chrome.runtime.sendMessage({ action: 'translate', text: text }, (response) => {
    setLoading(false);
    if (chrome.runtime.lastError) {
      showError('Connection error. Please try again.');
      return;
    }
    if (response && response.success) {
      showResult(response.translation, response.detectedLang);
      loadStats();
    } else {
      showError('ترجمہ میں خرابی آئی۔ انٹرنیٹ کنکشن چیک کریں۔');
    }
  });
}

clearBtn.addEventListener('click', () => {
  inputText.value = '';
  updateCharCount();
  hideResult();
  hideError();
  tipBox.style.display = 'block';
  inputText.focus();
});

pasteBtn.addEventListener('click', async () => {
  try {
    const text = await navigator.clipboard.readText();
    inputText.value = text;
    updateCharCount();
  } catch (e) {
    showError('Clipboard access denied. Please paste manually (Ctrl+V).');
  }
});

copyBtn.addEventListener('click', () => {
  const text = resultBox.textContent;
  navigator.clipboard.writeText(text).then(() => {
    showToast('copied!');
  }).catch(() => {
    const el = document.createElement('textarea');
    el.value = text;
    document.body.appendChild(el);
    el.select();
    document.execCommand('copy');
    document.body.removeChild(el);
    showToast('copied!');
  });
});

speakBtn.addEventListener('click', () => {
  const text = resultBox.textContent;
  if (!text) return;
  if ('speechSynthesis' in window) {
    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'ur-PK';
    utterance.rate = 0.85;
    utterance.pitch = 1;
    const voices = window.speechSynthesis.getVoices();
    const urduVoice = voices.find(v => v.lang.startsWith('ur'));
    if (urduVoice) utterance.voice = urduVoice;
    window.speechSynthesis.speak(utterance);
    speakBtn.textContent = 'Reading...';
    utterance.onend = () => { speakBtn.textContent = 'Read'; };
  }
});

chips.forEach(chip => {
  chip.addEventListener('click', () => {
    inputText.value = chip.dataset.text;
    updateCharCount();
    doTranslate();
  });
});

function setLoading(show) {
  loading.classList.toggle('show', show);
  translateBtn.disabled = show;
  translateBtn.innerHTML = show
    ? '<span>Loading...</span>'
    : '<span>Translate to Urdu</span>';
}

function showResult(translation, lang) {
  resultBox.textContent = translation;
  detectedLang.textContent = lang || 'Auto';
  resultSection.classList.add('show');
  tipBox.style.display = 'none';
}

function hideResult() {
  resultSection.classList.remove('show');
}

function showError(msg) {
  errorMsg.textContent = msg;
  errorBox.classList.add('show');
}

function hideError() {
  errorBox.classList.remove('show');
}

function showToast(msg) {
  toast.textContent = msg;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2500);
}
