// ===== URDU TRANSLATOR - Background Service Worker =====

// Create context menu on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "translateToUrdu",
    title: "🇵🇰 اردو میں ترجمہ کریں (Translate to Urdu)",
    contexts: ["selection"]
  });

  // Set default settings
  chrome.storage.local.set({
    autoTranslate: false,
    translationCount: 0
  });
});

// Context menu click handler
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "translateToUrdu" && info.selectionText) {
    const text = info.selectionText.trim();
    if (text && tab && tab.id) {
      translateText(text).then(result => {
        chrome.tabs.sendMessage(tab.id, {
          action: "showTranslation",
          original: text,
          translation: result.translation,
          detectedLang: result.detectedLang
        });
      }).catch(err => {
        chrome.tabs.sendMessage(tab.id, {
          action: "showTranslation",
          original: text,
          translation: "ترجمہ میں خرابی آئی۔ دوبارہ کوشش کریں۔",
          detectedLang: "unknown"
        });
      });
    }
  }
});

// Message listener from popup or content script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === "translate") {
    translateText(request.text)
      .then(result => {
        // Update translation count
        chrome.storage.local.get(["translationCount"], (data) => {
          const count = (data.translationCount || 0) + 1;
          chrome.storage.local.set({ translationCount: count });
        });
        sendResponse({ success: true, ...result });
      })
      .catch(err => {
        sendResponse({ success: false, error: err.message });
      });
    return true; // Keep channel open for async
  }

  if (request.action === "getStats") {
    chrome.storage.local.get(["translationCount"], (data) => {
      sendResponse({ translationCount: data.translationCount || 0 });
    });
    return true;
  }
});

// ===== Translation Function using Google Translate API =====
async function translateText(text) {
  const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=ur&dt=t&dt=ld&q=${encodeURIComponent(text)}`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error("Translation request failed");
  }

  const data = await response.json();

  // Extract translated text
  let translatedText = "";
  if (data && data[0]) {
    for (const segment of data[0]) {
      if (segment && segment[0]) {
        translatedText += segment[0];
      }
    }
  }

  // Extract detected language
  let detectedLang = "auto";
  if (data && data[8] && data[8][0] && data[8][0][0]) {
    detectedLang = data[8][0][0];
  } else if (data && data[2]) {
    detectedLang = data[2];
  }

  const langNames = {
    "en": "English",
    "ar": "Arabic (عربی)",
    "fr": "French (فرانسیسی)",
    "de": "German (جرمن)",
    "es": "Spanish (ہسپانوی)",
    "hi": "Hindi (ہندی)",
    "zh": "Chinese (چینی)",
    "zh-CN": "Chinese (چینی)",
    "ja": "Japanese (جاپانی)",
    "ko": "Korean (کوریائی)",
    "ru": "Russian (روسی)",
    "pt": "Portuguese (پرتگالی)",
    "it": "Italian (اطالوی)",
    "tr": "Turkish (ترکی)",
    "fa": "Persian (فارسی)",
    "bn": "Bengali (بنگالی)",
    "pa": "Punjabi (پنجابی)",
    "ur": "Urdu (اردو)",
    "auto": "Auto Detected"
  };

  return {
    translation: translatedText,
    detectedLang: langNames[detectedLang] || detectedLang.toUpperCase()
  };
}
