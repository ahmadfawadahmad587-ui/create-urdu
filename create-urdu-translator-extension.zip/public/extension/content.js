// ===== URDU TRANSLATOR - Content Script =====

let tooltip = null;
let isVisible = false;

// Listen for messages from background
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'showTranslation') {
    showFloatingTooltip(request.original, request.translation, request.detectedLang);
  }
});

// Show floating translation tooltip
function showFloatingTooltip(original, translation, detectedLang) {
  removeTooltip();

  tooltip = document.createElement('div');
  tooltip.id = 'urdu-translator-tooltip';
  tooltip.innerHTML = `
    <div class="ut-header">
      <span class="ut-logo">🌐</span>
      <span class="ut-title">اردو ترجمہ</span>
      <span class="ut-lang">${detectedLang || 'Auto'} → اردو</span>
      <button class="ut-close">✕</button>
    </div>
    <div class="ut-body">
      <div class="ut-original">${escapeHtml(original.substring(0, 100))}${original.length > 100 ? '...' : ''}</div>
      <div class="ut-arrow">↓</div>
      <div class="ut-translation">${escapeHtml(translation)}</div>
    </div>
    <div class="ut-footer">
      <button class="ut-copy-btn">📋 Copy</button>
      <span class="ut-powered">Powered by Urdu Translator</span>
    </div>
  `;

  // Position near selection
  const selection = window.getSelection();
  let x = 100, y = 100;
  if (selection && selection.rangeCount > 0) {
    const rect = selection.getRangeAt(0).getBoundingClientRect();
    x = Math.min(rect.left + window.scrollX, window.innerWidth - 380);
    y = rect.bottom + window.scrollY + 10;
    if (x < 10) x = 10;
  }

  tooltip.style.cssText = `
    position: absolute !important;
    top: ${y}px !important;
    left: ${x}px !important;
    z-index: 2147483647 !important;
    width: 360px !important;
    background: #0f0e17 !important;
    border: 1.5px solid rgba(79,70,229,0.4) !important;
    border-radius: 14px !important;
    box-shadow: 0 20px 60px rgba(0,0,0,0.5), 0 0 0 1px rgba(79,70,229,0.1) !important;
    font-family: 'Segoe UI', Arial, sans-serif !important;
    overflow: hidden !important;
    animation: utSlideIn 0.2s ease !important;
  `;

  // Style inner elements
  const style = document.createElement('style');
  style.textContent = `
    #urdu-translator-tooltip * { box-sizing: border-box !important; }
    #urdu-translator-tooltip .ut-header {
      background: linear-gradient(135deg, #1e1b4b, #312e81) !important;
      padding: 10px 14px !important;
      display: flex !important;
      align-items: center !important;
      gap: 8px !important;
    }
    #urdu-translator-tooltip .ut-logo { font-size: 16px !important; }
    #urdu-translator-tooltip .ut-title {
      font-size: 14px !important;
      font-weight: 700 !important;
      color: #e0e7ff !important;
      font-family: 'Noto Nastaliq Urdu', serif !important;
      direction: rtl !important;
    }
    #urdu-translator-tooltip .ut-lang {
      font-size: 10px !important;
      color: #818cf8 !important;
      margin-left: 4px !important;
    }
    #urdu-translator-tooltip .ut-close {
      margin-left: auto !important;
      background: rgba(255,255,255,0.1) !important;
      border: none !important;
      color: #9ca3af !important;
      cursor: pointer !important;
      width: 22px !important;
      height: 22px !important;
      border-radius: 50% !important;
      font-size: 11px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: center !important;
      transition: all 0.2s !important;
    }
    #urdu-translator-tooltip .ut-close:hover { background: rgba(244,63,94,0.3) !important; color: #fb7185 !important; }
    #urdu-translator-tooltip .ut-body { padding: 12px 14px !important; }
    #urdu-translator-tooltip .ut-original {
      font-size: 12px !important;
      color: #6b7280 !important;
      font-style: italic !important;
      border-left: 2px solid #374151 !important;
      padding-left: 8px !important;
      margin-bottom: 8px !important;
      direction: ltr !important;
      text-align: left !important;
    }
    #urdu-translator-tooltip .ut-arrow {
      font-size: 16px !important;
      color: #4f46e5 !important;
      text-align: center !important;
      margin-bottom: 8px !important;
    }
    #urdu-translator-tooltip .ut-translation {
      font-size: 20px !important;
      line-height: 2 !important;
      color: #e0e7ff !important;
      direction: rtl !important;
      text-align: right !important;
      font-family: 'Noto Nastaliq Urdu', Georgia, serif !important;
      background: rgba(79,70,229,0.08) !important;
      border: 1px solid rgba(79,70,229,0.2) !important;
      border-radius: 8px !important;
      padding: 10px 12px !important;
    }
    #urdu-translator-tooltip .ut-footer {
      border-top: 1px solid rgba(255,255,255,0.06) !important;
      padding: 8px 14px !important;
      display: flex !important;
      align-items: center !important;
      justify-content: space-between !important;
    }
    #urdu-translator-tooltip .ut-copy-btn {
      background: rgba(79,70,229,0.15) !important;
      border: 1px solid rgba(79,70,229,0.3) !important;
      color: #a5b4fc !important;
      font-size: 11px !important;
      padding: 4px 10px !important;
      border-radius: 6px !important;
      cursor: pointer !important;
      font-family: 'Segoe UI', Arial, sans-serif !important;
    }
    #urdu-translator-tooltip .ut-copy-btn:hover { background: rgba(79,70,229,0.3) !important; }
    #urdu-translator-tooltip .ut-powered { font-size: 10px !important; color: #374151 !important; }
    @keyframes utSlideIn {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;

  document.head.appendChild(style);
  document.body.appendChild(tooltip);
  isVisible = true;

  // Close button
  tooltip.querySelector('.ut-close').addEventListener('click', removeTooltip);

  // Copy button
  tooltip.querySelector('.ut-copy-btn').addEventListener('click', () => {
    navigator.clipboard.writeText(translation).catch(() => {});
    const btn = tooltip.querySelector('.ut-copy-btn');
    btn.textContent = 'Copied!';
    setTimeout(() => { if (btn) btn.textContent = 'Copy'; }, 2000);
  });

  // Close on outside click
  setTimeout(() => {
    document.addEventListener('click', handleOutsideClick);
  }, 100);
}

function handleOutsideClick(e) {
  if (tooltip && !tooltip.contains(e.target)) {
    removeTooltip();
  }
}

function removeTooltip() {
  if (tooltip) {
    tooltip.remove();
    tooltip = null;
    isVisible = false;
  }
  document.removeEventListener('click', handleOutsideClick);
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}
