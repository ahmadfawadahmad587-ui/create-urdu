====================================================
  URDU TRANSLATOR - Chrome Extension
  ہر زبان کو اردو میں ترجمہ کریں
====================================================

HOW TO INSTALL IN GOOGLE CHROME:
----------------------------------

STEP 1: Download this extension folder to your computer

STEP 2: Open Google Chrome browser

STEP 3: Type this in address bar:
        chrome://extensions/

STEP 4: Turn ON "Developer mode" (toggle in top-right corner)

STEP 5: Click "Load unpacked" button

STEP 6: Select the "extension" folder you downloaded

STEP 7: Done! You will see the Urdu Translator icon in your toolbar

====================================================

HOW TO USE:
-----------
1. Click the extension icon in toolbar to open popup
2. Type or paste any text in any language
3. Click "Translate to Urdu" to get instant translation
4. OR: Select any text on any webpage → Right-click → "اردو میں ترجمہ کریں"

FEATURES:
---------
✅ Translates ANY language to Urdu
✅ Right-click context menu on selected text
✅ Floating translation popup on webpages
✅ Text-to-speech (Read Urdu aloud)
✅ Copy translation to clipboard
✅ Quick phrase translations
✅ Translation counter
✅ Auto language detection

SUPPORTED LANGUAGES:
--------------------
English, Arabic, Hindi, French, German, Spanish, Chinese,
Japanese, Korean, Russian, Turkish, Persian, Bengali, 
and 100+ more languages!

====================================================
Version: 1.0.0
