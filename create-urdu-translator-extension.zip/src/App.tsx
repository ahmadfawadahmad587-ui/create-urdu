import { useState } from "react";

const LANGUAGES = [
  { code: "en", name: "English", flag: "🇬🇧", example: "Hello, how are you?" },
  { code: "ar", name: "عربی", flag: "🇸🇦", example: "مرحبا كيف حالك؟" },
  { code: "hi", name: "हिंदी", flag: "🇮🇳", example: "नमस्ते, कैसे हो?" },
  { code: "fr", name: "Français", flag: "🇫🇷", example: "Bonjour, comment ça va?" },
  { code: "de", name: "Deutsch", flag: "🇩🇪", example: "Hallo, wie geht es dir?" },
  { code: "es", name: "Español", flag: "🇪🇸", example: "Hola, ¿cómo estás?" },
  { code: "zh", name: "中文", flag: "🇨🇳", example: "你好，你好吗？" },
  { code: "ja", name: "日本語", flag: "🇯🇵", example: "こんにちは、お元気ですか？" },
  { code: "ru", name: "Русский", flag: "🇷🇺", example: "Привет, как дела?" },
  { code: "tr", name: "Türkçe", flag: "🇹🇷", example: "Merhaba, nasılsın?" },
];

const STEPS = [
  {
    num: "1",
    icon: "⬇️",
    title: "Download Extension",
    desc: "Download the Urdu Translator extension folder to your computer",
    color: "from-violet-500 to-indigo-600",
  },
  {
    num: "2",
    icon: "🔧",
    title: "Open Chrome Extensions",
    desc: 'Go to chrome://extensions/ and enable "Developer Mode" toggle',
    color: "from-indigo-500 to-blue-600",
  },
  {
    num: "3",
    icon: "📂",
    title: "Load Unpacked",
    desc: 'Click "Load unpacked" and select the downloaded extension folder',
    color: "from-blue-500 to-cyan-600",
  },
  {
    num: "4",
    icon: "✅",
    title: "Start Translating!",
    desc: "Click the 🌐 icon in Chrome toolbar and translate any language to Urdu!",
    color: "from-cyan-500 to-teal-600",
  },
];

const FEATURES = [
  { icon: "🌍", title: "100+ Languages", desc: "Auto-detect and translate from any language in the world to Urdu instantly" },
  { icon: "🖱️", title: "Right-Click Magic", desc: "Select any text on any webpage, right-click and get instant Urdu translation" },
  { icon: "💬", title: "Floating Tooltip", desc: "Beautiful floating popup appears right next to your selected text on the page" },
  { icon: "🔊", title: "Text to Speech", desc: "Listen to the Urdu translation read aloud in authentic Urdu pronunciation" },
  { icon: "📋", title: "One-Click Copy", desc: "Copy the Urdu translation to clipboard with a single click" },
  { icon: "⚡", title: "Quick Phrases", desc: "Pre-loaded common phrases for instant everyday translations" },
  { icon: "📊", title: "Translation Counter", desc: "Track how many translations you've done since installing the extension" },
  { icon: "🔒", title: "Privacy First", desc: "No data stored on servers. Translations are done in real-time via Google API" },
];

export default function App() {
  const [activeDemo, setActiveDemo] = useState(0);
  const [copied, setCopied] = useState(false);

  const handleCopyPath = () => {
    navigator.clipboard.writeText("chrome://extensions/").catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-screen bg-[#0a0914] text-white overflow-x-hidden">
      {/* Google Fonts */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Noto+Nastaliq+Urdu:wght@400;600;700&family=Inter:wght@300;400;500;600;700;800;900&display=swap');
        .urdu { font-family: 'Noto Nastaliq Urdu', serif; direction: rtl; }
        .inter { font-family: 'Inter', sans-serif; }
        @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-10px)} }
        @keyframes pulse-ring { 0%{box-shadow:0 0 0 0 rgba(79,70,229,0.4)} 70%{box-shadow:0 0 0 20px rgba(79,70,229,0)} 100%{box-shadow:0 0 0 0 rgba(79,70,229,0)} }
        @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
        .float { animation: float 3s ease-in-out infinite; }
        .pulse-ring { animation: pulse-ring 2s infinite; }
        .glow { box-shadow: 0 0 40px rgba(79,70,229,0.3); }
        .text-gradient { background: linear-gradient(135deg, #818cf8, #06b6d4); -webkit-background-clip: text; -webkit-text-fill-color: transparent; background-clip: text; }
        .card-hover { transition: all 0.3s ease; }
        .card-hover:hover { transform: translateY(-4px); box-shadow: 0 20px 40px rgba(79,70,229,0.2); }
        .lang-card:hover { border-color: rgba(79,70,229,0.5) !important; background: rgba(79,70,229,0.1) !important; }
      `}</style>

      {/* ===== HERO ===== */}
      <section className="relative min-h-screen flex flex-col items-center justify-center px-6 pt-16 pb-24 text-center overflow-hidden">
        {/* Background blobs */}
        <div className="absolute top-20 left-1/4 w-96 h-96 bg-violet-600/20 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-20 right-1/4 w-80 h-80 bg-cyan-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-900/20 rounded-full blur-3xl pointer-events-none" />

        {/* Badge */}
        <div className="inline-flex items-center gap-2 bg-white/5 border border-white/10 rounded-full px-4 py-2 text-sm text-indigo-300 mb-8">
          <span className="w-2 h-2 bg-green-400 rounded-full inline-block" style={{animation:"pulse 1.5s infinite"}} />
          Chrome Extension — Manifest V3 — Free
        </div>

        {/* Main icon */}
        <div className="float mb-8">
          <div className="w-28 h-28 rounded-3xl bg-gradient-to-br from-indigo-500 via-violet-600 to-cyan-500 flex items-center justify-center text-5xl glow mx-auto" style={{boxShadow:"0 0 60px rgba(99,102,241,0.5)"}}>
            🌐
          </div>
        </div>

        {/* Headline */}
        <h1 className="inter text-5xl md:text-7xl font-black mb-4 leading-tight max-w-4xl">
          Translate <span className="text-gradient">Everything</span>
          <br />to <span className="urdu text-6xl md:text-8xl font-bold" style={{color:"#a5b4fc", WebkitTextFillColor:"#a5b4fc"}}>اردو</span>
        </h1>

        <p className="inter text-lg md:text-xl text-gray-400 max-w-2xl mb-4">
          A powerful Chrome Extension that translates <strong className="text-white">100+ languages</strong> into beautiful Urdu — instantly, anywhere on the web.
        </p>

        <p className="urdu text-xl text-indigo-300 mb-10">
          ہر ویب سائٹ پر فوری اردو ترجمہ — کوئی بھی زبان
        </p>

        {/* CTA */}
        <div className="flex flex-col sm:flex-row gap-4 items-center mb-16">
          <a
            href="/extension/README.txt"
            target="_blank"
            className="inter px-8 py-4 bg-gradient-to-r from-indigo-600 to-violet-600 rounded-2xl font-bold text-lg hover:from-indigo-500 hover:to-violet-500 transition-all duration-300 shadow-lg shadow-indigo-500/30 flex items-center gap-2"
          >
            📥 Download Extension
          </a>
          <button
            onClick={() => document.getElementById('install')?.scrollIntoView({ behavior: 'smooth' })}
            className="inter px-8 py-4 bg-white/5 border border-white/10 rounded-2xl font-semibold text-lg hover:bg-white/10 transition-all duration-300 flex items-center gap-2"
          >
            📖 How to Install
          </button>
        </div>

        {/* Stats row */}
        <div className="flex flex-wrap justify-center gap-8 text-center">
          {[
            { val: "100+", label: "Languages" },
            { val: "Free", label: "Forever" },
            { val: "MV3", label: "Manifest V3" },
            { val: "اردو", label: "Output Language", urdu: true },
          ].map((s, i) => (
            <div key={i} className="px-6">
              <div className={`text-3xl font-black text-gradient ${s.urdu ? "urdu" : "inter"}`}>{s.val}</div>
              <div className="text-gray-500 text-sm inter mt-1">{s.label}</div>
            </div>
          ))}
        </div>
      </section>

      {/* ===== LIVE DEMO ===== */}
      <section className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <div className="inline-block text-sm text-cyan-400 bg-cyan-400/10 border border-cyan-400/20 rounded-full px-4 py-1 mb-4 inter">PREVIEW</div>
            <h2 className="inter text-4xl font-black mb-4">
              See it in <span className="text-gradient">Action</span>
            </h2>
            <p className="text-gray-400 inter">Click a language to see how the extension translates it to Urdu</p>
          </div>

          {/* Demo Card - Extension Popup Mockup */}
          <div className="flex flex-col lg:flex-row gap-8 items-start justify-center">

            {/* Language selector */}
            <div className="w-full lg:w-64 grid grid-cols-2 lg:grid-cols-1 gap-2">
              {LANGUAGES.map((lang, i) => (
                <button
                  key={i}
                  onClick={() => setActiveDemo(i)}
                  className={`lang-card flex items-center gap-3 p-3 rounded-xl border text-left transition-all duration-200 inter
                    ${activeDemo === i
                      ? "border-indigo-500 bg-indigo-500/15 text-white"
                      : "border-white/8 bg-white/3 text-gray-400"
                    }`}
                >
                  <span className="text-xl">{lang.flag}</span>
                  <div>
                    <div className="font-semibold text-sm">{lang.name}</div>
                    <div className="text-xs opacity-60 truncate w-24">{lang.example.substring(0, 20)}...</div>
                  </div>
                </button>
              ))}
            </div>

            {/* Extension popup mockup */}
            <div className="flex-1 max-w-md mx-auto">
              <div className="rounded-2xl overflow-hidden border border-white/10 shadow-2xl" style={{background:"#0f0e17"}}>
                {/* Header */}
                <div className="p-4 flex items-center gap-3" style={{background:"linear-gradient(135deg,#1e1b4b,#312e81 60%,#1e3a5f)"}}>
                  <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-cyan-500 flex items-center justify-center text-lg">🌐</div>
                  <div>
                    <div className="inter font-bold text-sm">Urdu Translator</div>
                    <div className="urdu text-xs text-indigo-300">ہر زبان، اردو میں</div>
                  </div>
                  <div className="ml-auto bg-white/10 border border-white/15 rounded-full px-3 py-1 text-xs text-indigo-300 inter">
                    <span className="font-bold text-sm">42</span> ترجمے
                  </div>
                </div>

                {/* Lang bar */}
                <div className="flex items-center gap-2 p-3" style={{background:"#1a1929", borderBottom:"1px solid rgba(255,255,255,0.08)"}}>
                  <div className="flex-1 rounded-lg p-2 text-center text-xs inter" style={{background:"#252438", border:"1px solid rgba(255,255,255,0.08)"}}>
                    <div className="font-bold text-white text-sm">{LANGUAGES[activeDemo].flag} {LANGUAGES[activeDemo].name}</div>
                    <div className="text-gray-500">Detected</div>
                  </div>
                  <span className="text-indigo-400 text-lg">→</span>
                  <div className="flex-1 rounded-lg p-2 text-center text-xs inter" style={{background:"rgba(79,70,229,0.1)", border:"1px solid rgba(79,70,229,0.35)"}}>
                    <div className="urdu font-bold text-indigo-300 text-base">اردو</div>
                    <div className="text-gray-500 inter">Urdu</div>
                  </div>
                </div>

                {/* Input */}
                <div className="p-4">
                  <div className="text-xs text-gray-500 inter uppercase tracking-wider mb-2">متن درج کریں</div>
                  <div className="rounded-xl p-3 text-sm inter text-gray-300" style={{background:"#1a1929", border:"1px solid rgba(255,255,255,0.08)", minHeight:"70px"}}>
                    {LANGUAGES[activeDemo].example}
                  </div>

                  {/* Translate button */}
                  <button className="w-full mt-3 py-3 rounded-xl font-bold inter text-sm text-white flex items-center justify-center gap-2"
                    style={{background:"linear-gradient(135deg,#4f46e5,#4338ca)", boxShadow:"0 4px 15px rgba(79,70,229,0.3)"}}>
                    🔄 Translate to Urdu
                  </button>

                  {/* Result */}
                  <div className="mt-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-xs text-gray-500 inter uppercase tracking-wider">اردو ترجمہ</span>
                      <span className="ml-auto text-xs rounded-full px-2 py-0.5 inter" style={{background:"rgba(6,182,212,0.1)", border:"1px solid rgba(6,182,212,0.25)", color:"#22d3ee"}}>{LANGUAGES[activeDemo].name}</span>
                    </div>
                    <div className="rounded-xl p-4 urdu text-lg" style={{background:"rgba(79,70,229,0.08)", border:"1px solid rgba(79,70,229,0.2)", lineHeight:"2.2", color:"#e0e7ff", textAlign:"right", direction:"rtl", minHeight:"70px"}}>
                      {getUrduTranslation(activeDemo)}
                    </div>
                    <div className="flex gap-2 mt-2 justify-end">
                      <span className="text-xs inter px-3 py-1.5 rounded-lg cursor-pointer" style={{background:"#252438", border:"1px solid rgba(255,255,255,0.08)", color:"#9ca3af"}}>📋 Copy</span>
                      <span className="text-xs inter px-3 py-1.5 rounded-lg cursor-pointer" style={{background:"#252438", border:"1px solid rgba(255,255,255,0.08)", color:"#9ca3af"}}>🔊 Read</span>
                    </div>
                  </div>
                </div>

                {/* Footer */}
                <div className="px-4 py-2 flex justify-between text-xs" style={{borderTop:"1px solid rgba(255,255,255,0.06)", color:"#374151"}}>
                  <span>Powered by Google Translate API</span>
                  <span>اردو ترجمہ v1.0</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== FEATURES ===== */}
      <section className="py-20 px-6" style={{background:"linear-gradient(180deg, #0a0914 0%, #0d0b1a 100%)"}}>
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-14">
            <div className="inline-block text-sm text-violet-400 bg-violet-400/10 border border-violet-400/20 rounded-full px-4 py-1 mb-4 inter">FEATURES</div>
            <h2 className="inter text-4xl font-black mb-4">Everything You <span className="text-gradient">Need</span></h2>
            <p className="text-gray-400 inter max-w-xl mx-auto">A complete translation powerhouse, built specifically for Urdu speakers</p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {FEATURES.map((f, i) => (
              <div key={i} className="card-hover rounded-2xl p-5 border border-white/8 cursor-default" style={{background:"rgba(255,255,255,0.03)"}}>
                <div className="text-3xl mb-3">{f.icon}</div>
                <h3 className="inter font-bold text-base mb-2 text-white">{f.title}</h3>
                <p className="inter text-sm text-gray-500 leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== INSTALLATION STEPS ===== */}
      <section id="install" className="py-20 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <div className="inline-block text-sm text-green-400 bg-green-400/10 border border-green-400/20 rounded-full px-4 py-1 mb-4 inter">INSTALLATION</div>
            <h2 className="inter text-4xl font-black mb-4">
              Install in <span className="text-gradient">4 Simple Steps</span>
            </h2>
            <p className="text-gray-400 inter">No coding required. Ready in under 2 minutes!</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-14">
            {STEPS.map((step, i) => (
              <div key={i} className="card-hover relative rounded-2xl p-6 border border-white/8" style={{background:"rgba(255,255,255,0.03)"}}>
                <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${step.color} flex items-center justify-center text-xl mb-4`}>
                  {step.icon}
                </div>
                <div className="absolute top-4 right-4 w-6 h-6 rounded-full bg-white/5 flex items-center justify-center text-xs font-bold text-gray-400">{step.num}</div>
                <h3 className="inter font-bold text-white mb-2">{step.title}</h3>
                <p className="inter text-sm text-gray-500 leading-relaxed">{step.desc}</p>
                {i < 3 && (
                  <div className="hidden lg:block absolute top-1/2 -right-3 text-gray-600 text-xl">→</div>
                )}
              </div>
            ))}
          </div>

          {/* Important note box */}
          <div className="rounded-2xl p-6 border" style={{background:"rgba(79,70,229,0.08)", borderColor:"rgba(79,70,229,0.3)"}}>
            <h3 className="inter font-bold text-indigo-300 mb-4 flex items-center gap-2 text-lg">
              <span>🔑</span> Chrome URL to Enable Developer Mode:
            </h3>
            <div className="flex items-center gap-3 flex-wrap">
              <code className="bg-black/40 border border-white/10 rounded-xl px-5 py-3 text-cyan-300 font-mono text-base">
                chrome://extensions/
              </code>
              <button
                onClick={handleCopyPath}
                className="inter px-5 py-3 rounded-xl font-semibold text-sm transition-all duration-200"
                style={{background: copied ? "rgba(16,185,129,0.2)" : "rgba(79,70,229,0.2)", border: copied ? "1px solid rgba(16,185,129,0.4)" : "1px solid rgba(79,70,229,0.4)", color: copied ? "#10b981" : "#a5b4fc"}}
              >
                {copied ? "✅ Copied!" : "📋 Copy URL"}
              </button>
              <span className="inter text-sm text-gray-500">Paste this in Chrome address bar → Enable Developer Mode → Load Unpacked</span>
            </div>
          </div>
        </div>
      </section>

      {/* ===== CONTEXT MENU DEMO ===== */}
      <section className="py-20 px-6" style={{background:"linear-gradient(180deg, #0a0914 0%, #0d0b1a 100%)"}}>
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-14">
            <div className="inline-block text-sm text-cyan-400 bg-cyan-400/10 border border-cyan-400/20 rounded-full px-4 py-1 mb-4 inter">RIGHT-CLICK FEATURE</div>
            <h2 className="inter text-4xl font-black mb-4">Translate on <span className="text-gradient">Any Website</span></h2>
            <p className="text-gray-400 inter max-w-xl mx-auto">Select any text on any webpage, right-click, and instantly see the Urdu translation</p>
          </div>

          <div className="flex flex-col lg:flex-row gap-8 items-center justify-center">
            {/* Step visuals */}
            <div className="flex flex-col gap-4 w-full lg:w-64">
              {[
                { icon: "🖱️", step: "Select text on any website" },
                { icon: "📋", step: "Right-click to open context menu" },
                { icon: "🇵🇰", step: 'Click "اردو میں ترجمہ کریں"' },
                { icon: "✨", step: "Floating Urdu translation appears!" },
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3 inter">
                  <div className="w-10 h-10 rounded-xl flex items-center justify-center text-xl flex-shrink-0"
                    style={{background:"rgba(79,70,229,0.15)", border:"1px solid rgba(79,70,229,0.3)"}}>
                    {item.icon}
                  </div>
                  <span className="text-sm text-gray-400">{item.step}</span>
                </div>
              ))}
            </div>

            {/* Floating tooltip mockup */}
            <div className="flex-1 max-w-sm">
              <div className="relative">
                {/* Fake webpage */}
                <div className="rounded-2xl p-5 border border-white/8 mb-0" style={{background:"rgba(255,255,255,0.03)"}}>
                  <div className="text-xs text-gray-500 inter mb-3 flex gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500/50" />
                    <span className="w-3 h-3 rounded-full bg-yellow-500/50" />
                    <span className="w-3 h-3 rounded-full bg-green-500/50" />
                    <span className="ml-2">example-website.com</span>
                  </div>
                  <p className="inter text-sm text-gray-400 leading-relaxed">
                    The world is a beautiful place, full of{" "}
                    <span className="bg-indigo-500/30 text-white px-1 rounded" style={{border:"1px solid rgba(79,70,229,0.5)"}}>
                      wonderful languages and cultures
                    </span>
                    {" "}that connect us all together.
                  </p>

                  {/* Context menu */}
                  <div className="mt-3 rounded-xl overflow-hidden border border-white/10 inline-block" style={{background:"#1a1929", minWidth:"220px"}}>
                    <div className="px-4 py-2 text-xs text-gray-500 inter border-b border-white/5">Chrome Context Menu</div>
                    <div className="px-4 py-2 text-sm inter text-gray-400 hover:bg-white/5">Copy</div>
                    <div className="px-4 py-2 text-sm inter text-gray-400 hover:bg-white/5">Search Google...</div>
                    <div className="px-4 py-2 text-sm inter flex items-center gap-2" style={{background:"rgba(79,70,229,0.2)", color:"#a5b4fc", borderLeft:"3px solid #4f46e5"}}>
                      🇵🇰 <span className="urdu">اردو میں ترجمہ کریں</span>
                    </div>
                    <div className="px-4 py-2 text-sm inter text-gray-400 hover:bg-white/5">Inspect</div>
                  </div>
                </div>

                {/* Floating tooltip result */}
                <div className="mt-4 rounded-2xl overflow-hidden border" style={{background:"#0f0e17", borderColor:"rgba(79,70,229,0.4)", boxShadow:"0 20px 60px rgba(0,0,0,0.5)"}}>
                  <div className="p-3 flex items-center gap-2" style={{background:"linear-gradient(135deg,#1e1b4b,#312e81)"}}>
                    <span>🌐</span>
                    <span className="urdu text-sm text-indigo-300">اردو ترجمہ</span>
                    <span className="ml-auto text-xs text-indigo-400 inter">English → اردو</span>
                    <button className="ml-2 text-gray-500 text-xs hover:text-white">✕</button>
                  </div>
                  <div className="p-4">
                    <div className="text-xs text-gray-600 inter italic border-l-2 border-gray-700 pl-2 mb-3">
                      "wonderful languages and cultures"
                    </div>
                    <div className="urdu text-xl p-3 rounded-xl" style={{lineHeight:"2.2", color:"#e0e7ff", background:"rgba(79,70,229,0.08)", border:"1px solid rgba(79,70,229,0.2)", direction:"rtl", textAlign:"right"}}>
                      شاندار زبانیں اور ثقافتیں
                    </div>
                  </div>
                  <div className="px-4 py-2 flex items-center justify-between" style={{borderTop:"1px solid rgba(255,255,255,0.06)"}}>
                    <button className="text-xs inter px-3 py-1 rounded-lg" style={{background:"rgba(79,70,229,0.15)", border:"1px solid rgba(79,70,229,0.3)", color:"#a5b4fc"}}>📋 Copy</button>
                    <span className="text-xs text-gray-600 inter">Urdu Translator</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ===== DOWNLOAD SECTION ===== */}
      <section className="py-24 px-6 text-center">
        <div className="max-w-3xl mx-auto">
          <div className="float mb-8">
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-indigo-500 via-violet-600 to-cyan-500 flex items-center justify-center text-4xl mx-auto" style={{boxShadow:"0 0 60px rgba(99,102,241,0.4)"}}>
              📥
            </div>
          </div>
          <h2 className="inter text-5xl font-black mb-4">
            Ready to Translate?
          </h2>
          <p className="urdu text-2xl text-indigo-300 mb-3">کیا آپ ترجمہ کرنے کے لیے تیار ہیں؟</p>
          <p className="inter text-gray-400 mb-10 text-lg">Download the extension and start translating every language to Urdu in seconds!</p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-10">
            <a
              href="/extension"
              className="inter px-10 py-5 rounded-2xl font-black text-xl text-white flex items-center justify-center gap-3 transition-all duration-300"
              style={{background:"linear-gradient(135deg,#4f46e5,#7c3aed)", boxShadow:"0 8px 30px rgba(79,70,229,0.4)"}}
            >
              📥 Download Extension Folder
            </a>
          </div>

          {/* File structure */}
          <div className="rounded-2xl p-6 text-left" style={{background:"rgba(255,255,255,0.03)", border:"1px solid rgba(255,255,255,0.08)"}}>
            <h3 className="inter font-bold text-gray-300 mb-4 text-sm uppercase tracking-wider">📁 Extension File Structure</h3>
            <div className="font-mono text-sm space-y-1">
              {[
                { indent: 0, icon: "📁", name: "extension/", color: "#fbbf24" },
                { indent: 1, icon: "📄", name: "manifest.json", color: "#34d399", desc: "— Extension config" },
                { indent: 1, icon: "📄", name: "popup.html", color: "#60a5fa", desc: "— Main UI" },
                { indent: 1, icon: "📜", name: "popup.js", color: "#a78bfa", desc: "— Popup logic" },
                { indent: 1, icon: "📜", name: "background.js", color: "#a78bfa", desc: "— Background worker" },
                { indent: 1, icon: "📜", name: "content.js", color: "#a78bfa", desc: "— Page injection" },
                { indent: 1, icon: "🎨", name: "content.css", color: "#f472b6", desc: "— Tooltip styles" },
                { indent: 1, icon: "📁", name: "icons/", color: "#fbbf24" },
                { indent: 2, icon: "🖼️", name: "icon16.png", color: "#9ca3af" },
                { indent: 2, icon: "🖼️", name: "icon48.png", color: "#9ca3af" },
                { indent: 2, icon: "🖼️", name: "icon128.png", color: "#9ca3af" },
              ].map((f, i) => (
                <div key={i} className="flex items-center gap-2" style={{paddingLeft: `${f.indent * 20}px`}}>
                  <span>{f.icon}</span>
                  <span style={{color: f.color}}>{f.name}</span>
                  {f.desc && <span className="text-gray-600">{f.desc}</span>}
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ===== FOOTER ===== */}
      <footer className="py-10 px-6 text-center border-t border-white/5">
        <div className="urdu text-2xl text-indigo-400 mb-2">اردو ترجمہ</div>
        <p className="inter text-gray-600 text-sm">ہر زبان، اردو میں • Every Language, in Urdu</p>
        <p className="inter text-gray-700 text-xs mt-3">Chrome Extension v1.0 • Manifest V3 • Free Forever</p>
      </footer>
    </div>
  );
}

function getUrduTranslation(index: number): string {
  const translations = [
    "ہیلو، آپ کیسے ہیں؟",
    "مرحبا، كيف حالك؟ — سلام، آپ کیسے ہیں؟",
    "ہیلو، آپ کیسے ہیں؟",
    "ہیلو، کیا حال ہے؟",
    "ہیلو، تم کیسے ہو؟",
    "ہیلو، تم کیسے ہو؟",
    "ہیلو، آپ کیسے ہیں؟",
    "こんにちは — ہیلو، آپ کا کیا حال ہے؟",
    "Привет — ہیلو، کیا حال ہے؟",
    "مرحبا، آپ کیسے ہیں؟",
  ];
  return translations[index] || "ہیلو، آپ کیسے ہیں؟";
}
